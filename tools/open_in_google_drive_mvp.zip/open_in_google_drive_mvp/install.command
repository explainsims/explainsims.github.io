#!/bin/zsh
set -e

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$SCRIPT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 was not found. Install Python 3 from python.org, then run this installer again."
  read -k 1 "?Press any key to close..."
  exit 1
fi

python3 -m venv .venv
./.venv/bin/python3 -m pip install --upgrade pip
./.venv/bin/python3 -m pip install -r requirements.txt
chmod +x open_in_google_drive.py open_in_google_drive_wrapper.sh install.command

echo
echo "Installation complete."
echo "Next: add client_secret.json to this folder, then follow README.md to create the Finder Quick Action."
echo
read -k 1 "?Press any key to close..."
