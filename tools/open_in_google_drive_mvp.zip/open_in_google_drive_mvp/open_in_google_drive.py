#!/usr/bin/env python3
"""Upload Finder-selected files to Google Drive and open them in Google Workspace.

Convertible document, spreadsheet, and presentation formats are imported as
native Google Docs, Sheets, or Slides files. Other files are uploaded unchanged
and opened in Google Drive.
"""

from __future__ import annotations

import argparse
import logging
import mimetypes
import os
import subprocess
import sys
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload

APP_NAME = "Open in Google Drive"
SCOPES = ["https://www.googleapis.com/auth/drive.file"]
GOOGLE_DOC = "application/vnd.google-apps.document"
GOOGLE_SHEET = "application/vnd.google-apps.spreadsheet"
GOOGLE_SLIDES = "application/vnd.google-apps.presentation"

# Formats that should be imported into native Google Workspace files.
# If Google rejects a conversion, the script automatically uploads the original
# file unchanged instead of losing the whole operation.
CONVERSION_MAP: dict[str, str] = {
    # Google Docs
    ".doc": GOOGLE_DOC,
    ".docx": GOOGLE_DOC,
    ".odt": GOOGLE_DOC,
    ".rtf": GOOGLE_DOC,
    ".txt": GOOGLE_DOC,
    ".html": GOOGLE_DOC,
    ".htm": GOOGLE_DOC,
    ".md": GOOGLE_DOC,
    # Google Sheets
    ".csv": GOOGLE_SHEET,
    ".tsv": GOOGLE_SHEET,
    ".xls": GOOGLE_SHEET,
    ".xlsx": GOOGLE_SHEET,
    ".xlsm": GOOGLE_SHEET,
    ".ods": GOOGLE_SHEET,
    # Google Slides
    ".ppt": GOOGLE_SLIDES,
    ".pptx": GOOGLE_SLIDES,
    ".odp": GOOGLE_SLIDES,
}

WORKSPACE_LABELS = {
    GOOGLE_DOC: "Docs",
    GOOGLE_SHEET: "Sheets",
    GOOGLE_SLIDES: "Slides",
}

# Add common MIME types that Python/macOS may not know consistently.
mimetypes.add_type("text/csv", ".csv")
mimetypes.add_type("text/tab-separated-values", ".tsv")
mimetypes.add_type("application/vnd.ms-excel", ".xls")
mimetypes.add_type(
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"
)
mimetypes.add_type("application/vnd.ms-excel.sheet.macroEnabled.12", ".xlsm")
mimetypes.add_type("application/vnd.ms-powerpoint", ".ppt")
mimetypes.add_type(
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".pptx",
)
mimetypes.add_type("application/msword", ".doc")
mimetypes.add_type(
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".docx",
)


@dataclass
class UploadResult:
    source: Path
    success: bool
    destination_name: str = ""
    destination_kind: str = ""
    url: str = ""
    fallback_used: bool = False
    error: str = ""


def app_directory() -> Path:
    return Path(__file__).resolve().parent


def log_directory() -> Path:
    path = Path.home() / "Library" / "Logs" / "OpenInGoogleDrive"
    path.mkdir(parents=True, exist_ok=True)
    return path


def configure_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(log_directory() / "open_in_google_drive.log", encoding="utf-8"),
            logging.StreamHandler(sys.stderr),
        ],
    )


def notify(title: str, message: str) -> None:
    """Display a macOS notification without requiring another dependency."""
    safe_title = title.replace("\\", "\\\\").replace('"', '\\"')
    safe_message = message.replace("\\", "\\\\").replace('"', '\\"')
    script = f'display notification "{safe_message}" with title "{safe_title}"'
    try:
        subprocess.run(
            ["/usr/bin/osascript", "-e", script],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError:
        logging.debug("Could not display macOS notification", exc_info=True)


def credentials_paths() -> tuple[Path, Path]:
    base = app_directory()
    return base / "client_secret.json", base / "token.json"


def get_credentials() -> Credentials:
    client_secret_path, token_path = credentials_paths()

    if not client_secret_path.exists():
        raise FileNotFoundError(
            f"Missing {client_secret_path.name}. Download a Desktop app OAuth client "
            f"from Google Cloud and place it in {app_directory()}."
        )

    credentials: Credentials | None = None
    if token_path.exists():
        try:
            credentials = Credentials.from_authorized_user_file(str(token_path), SCOPES)
        except Exception:
            logging.warning("Saved token could not be read; starting sign-in again.", exc_info=True)

    if credentials and credentials.expired and credentials.refresh_token:
        try:
            credentials.refresh(Request())
        except Exception:
            logging.warning("Token refresh failed; starting sign-in again.", exc_info=True)
            credentials = None

    if not credentials or not credentials.valid:
        flow = InstalledAppFlow.from_client_secrets_file(str(client_secret_path), SCOPES)
        credentials = flow.run_local_server(port=0, open_browser=True)

    token_path.write_text(credentials.to_json(), encoding="utf-8")
    try:
        os.chmod(token_path, 0o600)
    except OSError:
        logging.debug("Could not restrict token.json permissions", exc_info=True)

    return credentials


def normalise_paths(raw_paths: Iterable[str]) -> list[Path]:
    seen: set[Path] = set()
    paths: list[Path] = []

    for raw in raw_paths:
        path = Path(raw).expanduser()
        try:
            resolved = path.resolve(strict=False)
        except OSError:
            resolved = path.absolute()
        if resolved not in seen:
            seen.add(resolved)
            paths.append(resolved)

    return paths


def source_mime_type(path: Path) -> str:
    guessed, _encoding = mimetypes.guess_type(path.name)
    return guessed or "application/octet-stream"


def destination_metadata(path: Path, target_mime: str | None) -> dict[str, str]:
    if target_mime:
        return {"name": path.stem, "mimeType": target_mime}
    return {"name": path.name}


def create_file(service, path: Path, target_mime: str | None):
    media = MediaFileUpload(
        str(path),
        mimetype=source_mime_type(path),
        resumable=path.stat().st_size >= 5 * 1024 * 1024,
    )
    return (
        service.files()
        .create(
            body=destination_metadata(path, target_mime),
            media_body=media,
            fields="id,name,mimeType,webViewLink",
            supportsAllDrives=False,
        )
        .execute()
    )


def file_url(created: dict[str, str]) -> str:
    if created.get("webViewLink"):
        return created["webViewLink"]

    file_id = created["id"]
    mime_type = created.get("mimeType", "")
    if mime_type == GOOGLE_DOC:
        return f"https://docs.google.com/document/d/{file_id}/edit"
    if mime_type == GOOGLE_SHEET:
        return f"https://docs.google.com/spreadsheets/d/{file_id}/edit"
    if mime_type == GOOGLE_SLIDES:
        return f"https://docs.google.com/presentation/d/{file_id}/edit"
    return f"https://drive.google.com/file/d/{file_id}/view"


def upload_one(service, path: Path) -> UploadResult:
    if not path.exists():
        return UploadResult(path, False, error="File does not exist")
    if not path.is_file():
        return UploadResult(path, False, error="Folders and special files are not supported")
    if path.is_symlink():
        return UploadResult(path, False, error="Symbolic links are not supported")

    target_mime = CONVERSION_MAP.get(path.suffix.lower())
    fallback_used = False

    try:
        created = create_file(service, path, target_mime)
    except HttpError as conversion_error:
        if not target_mime:
            return UploadResult(path, False, error=f"Google Drive upload failed: {conversion_error}")

        logging.warning(
            "Conversion failed for %s; uploading the original unchanged.", path.name
        )
        logging.debug("Conversion error", exc_info=True)
        fallback_used = True
        try:
            created = create_file(service, path, None)
        except HttpError as upload_error:
            return UploadResult(
                path,
                False,
                error=f"Conversion and fallback upload failed: {upload_error}",
            )
    except OSError as error:
        return UploadResult(path, False, error=str(error))

    created_mime = created.get("mimeType", "")
    kind = WORKSPACE_LABELS.get(created_mime, "Drive")
    return UploadResult(
        source=path,
        success=True,
        destination_name=created.get("name", path.name),
        destination_kind=kind,
        url=file_url(created),
        fallback_used=fallback_used,
    )


def open_urls(results: list[UploadResult], delay: float) -> None:
    successful = [result for result in results if result.success and result.url]
    for index, result in enumerate(successful):
        logging.info("Opening %s", result.url)
        webbrowser.open(result.url, new=2)
        if index < len(successful) - 1 and delay > 0:
            time.sleep(delay)


def result_summary(results: list[UploadResult]) -> str:
    successes = [result for result in results if result.success]
    failures = [result for result in results if not result.success]

    counts: dict[str, int] = {}
    for result in successes:
        counts[result.destination_kind] = counts.get(result.destination_kind, 0) + 1

    parts = [f"{count} {kind}" for kind, count in counts.items()]
    successful_text = ", ".join(parts) if parts else "0 files"
    if failures:
        return f"Uploaded {successful_text}; {len(failures)} failed."
    return f"Uploaded {successful_text}."


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Upload files to Google Drive and open them in Docs, Sheets, Slides, or Drive."
    )
    parser.add_argument("paths", nargs="+", help="One or more local files")
    parser.add_argument(
        "--no-open", action="store_true", help="Upload files without opening browser tabs"
    )
    parser.add_argument(
        "--open-delay",
        type=float,
        default=0.35,
        help="Seconds between opening multiple browser tabs (default: 0.35)",
    )
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    configure_logging(args.verbose)
    paths = normalise_paths(args.paths)
    logging.info("Starting %s for %d selected item(s)", APP_NAME, len(paths))

    try:
        credentials = get_credentials()
        service = build("drive", "v3", credentials=credentials, cache_discovery=False)
    except Exception as error:
        message = str(error)
        logging.exception("Could not initialise Google Drive access")
        notify(APP_NAME, f"Setup or sign-in failed: {message[:160]}")
        print(f"ERROR: {message}", file=sys.stderr)
        return 2

    results = [upload_one(service, path) for path in paths]

    for result in results:
        if result.success:
            fallback_note = " (uploaded unchanged after conversion failed)" if result.fallback_used else ""
            logging.info(
                "Uploaded %s as %s '%s'%s",
                result.source,
                result.destination_kind,
                result.destination_name,
                fallback_note,
            )
            print(f"OK: {result.source.name} -> {result.destination_kind}: {result.url}")
        else:
            logging.error("Failed %s: %s", result.source, result.error)
            print(f"FAILED: {result.source}: {result.error}", file=sys.stderr)

    if not args.no_open:
        open_urls(results, max(0.0, args.open_delay))

    summary = result_summary(results)
    notify(APP_NAME, summary)
    print(summary)
    return 0 if all(result.success for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
