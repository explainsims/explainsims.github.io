#!/bin/zsh
# Automator passes every selected Finder file as a separate argument.
# This wrapper uses the virtual environment stored beside the Python script.

set -u

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
PYTHON="$SCRIPT_DIR/.venv/bin/python3"
SCRIPT="$SCRIPT_DIR/open_in_google_drive.py"
LOG_DIR="$HOME/Library/Logs/OpenInGoogleDrive"
LOG_FILE="$LOG_DIR/automator.log"

mkdir -p "$LOG_DIR"

if [[ ! -x "$PYTHON" ]]; then
  /usr/bin/osascript -e 'display dialog "Open in Google Drive is not installed yet. Run install.command in the project folder first." with title "Open in Google Drive" buttons {"OK"} default button "OK" with icon caution'
  exit 1
fi

if (( $# == 0 )); then
  /usr/bin/osascript -e 'display notification "No files were supplied by Finder." with title "Open in Google Drive"'
  exit 1
fi

"$PYTHON" "$SCRIPT" "$@" >> "$LOG_FILE" 2>&1
STATUS=$?

if (( STATUS != 0 )); then
  /usr/bin/osascript -e 'display notification "One or more files could not be uploaded. See the log for details." with title "Open in Google Drive"'
fi

exit $STATUS
