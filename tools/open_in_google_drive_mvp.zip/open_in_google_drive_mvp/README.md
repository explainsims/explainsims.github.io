# Open in Google Drive - macOS Finder Quick Action MVP

Right-click one or more files in Finder, choose **Quick Actions > Open in Google Drive**, and the utility will:

1. Authenticate with one Google account using OAuth.
2. Upload each selected file to the root of **My Drive**.
3. Convert compatible files into native Google Docs, Sheets, or Slides.
4. Upload everything else unchanged.
5. Open each uploaded result in your default browser.
6. Show a macOS notification summarising the result.

The utility always creates a new Drive file. Existing files are never overwritten or deleted.

## Automatic routing

### Convert to Google Docs

- `.doc`
- `.docx`
- `.odt`
- `.rtf`
- `.txt`
- `.html`
- `.htm`
- `.md`

### Convert to Google Sheets

- `.csv`
- `.tsv`
- `.xls`
- `.xlsx`
- `.xlsm`
- `.ods`

### Convert to Google Slides

- `.ppt`
- `.pptx`
- `.odp`

### Upload unchanged to Google Drive

All other regular files, including common examples such as:

- PDF: `.pdf`
- Images: `.jpg`, `.jpeg`, `.png`, `.gif`, `.tiff`, `.svg`, `.webp`
- Audio: `.mp3`, `.wav`, `.m4a`, `.aac`, `.ogg`, `.opus`
- Video: `.mp4`, `.mov`, `.m4v`, `.avi`, `.webm`
- Archives: `.zip`, `.rar`, `.7z`, `.tar`, `.gz`
- Code and data files: `.py`, `.js`, `.json`, `.xml`, `.yaml`, `.css`, and others
- Apple iWork files: `.pages`, `.numbers`, `.key` - stored unchanged because Google cannot directly convert their native package formats through this workflow

PDFs and images are deliberately uploaded unchanged rather than OCR-converted. That preserves the original file and avoids creating badly formatted Google Docs.

If a normally convertible format is rejected by Google, the utility falls back to uploading the original file unchanged and opens it in Drive.

---

## Requirements

- macOS
- Python 3.10 or later recommended
- A Google account
- A Google Cloud project with the Google Drive API enabled
- An OAuth 2.0 **Desktop app** client

No separate personal/work account selector is included. The first OAuth sign-in chooses the account used by the utility. To change accounts later, delete `token.json` and run the action again.

---

## 1. Put the folder somewhere permanent

Move the extracted folder to:

```text
~/open-in-google-drive
```

The path may be different, but do not move or rename it after creating the Automator Quick Action unless you also update the path in Automator.

---

## 2. Install the Python environment

Double-click:

```text
install.command
```

If macOS blocks it:

1. Right-click `install.command`.
2. Choose **Open**.
3. Confirm **Open**.

Alternatively, run in Terminal:

```bash
cd ~/open-in-google-drive
chmod +x install.command
./install.command
```

The installer creates a local `.venv` folder and installs the required Google libraries.

---

## 3. Create the Google Cloud project

1. Open Google Cloud Console.
2. Create a new project, or select a project you control.
3. Open **APIs & Services > Library**.
4. Search for **Google Drive API**.
5. Open it and click **Enable**.

Only the Google Drive API is required. The utility does not need separate Docs, Sheets, or Slides APIs because conversion is performed during the Drive upload.

---

## 4. Configure Google Auth Platform / OAuth consent

Google changes the exact Cloud Console labels occasionally, but the required configuration is:

1. Open **Google Auth Platform** or **APIs & Services > OAuth consent screen**.
2. Configure the app name, support email, and developer contact email.
3. Choose the audience that fits your account:
   - **Internal** if this is a Google Workspace organisation project and only organisation users will use it.
   - **External** for a normal Google account or broader use.
4. If the app remains in testing mode, add your Google account under **Test users**.
5. Save the configuration.

The script requests only:

```text
https://www.googleapis.com/auth/drive.file
```

This permits the utility to create and manage files it creates or opens through the app, rather than granting blanket access to every file in Drive.

---

## 5. Create the Desktop OAuth client

1. Open **Google Auth Platform > Clients** or **APIs & Services > Credentials**.
2. Choose **Create client** or **Create credentials > OAuth client ID**.
3. Select **Desktop app** as the application type.
4. Give it a recognisable name, such as `Open in Google Drive for Mac`.
5. Download the JSON credentials file.
6. Rename it exactly:

```text
client_secret.json
```

7. Place it inside the project folder beside `open_in_google_drive.py`.

The folder should now include:

```text
open-in-google-drive/
├── .venv/
├── client_secret.json
├── install.command
├── open_in_google_drive.py
├── open_in_google_drive_wrapper.sh
├── README.md
└── requirements.txt
```

Do not share `client_secret.json` or `token.json` publicly.

---

## 6. Test the script directly

Use a small local file for the first test:

```bash
cd ~/open-in-google-drive
./.venv/bin/python3 open_in_google_drive.py "/full/path/to/test.csv"
```

For several files:

```bash
./.venv/bin/python3 open_in_google_drive.py \
  "/full/path/to/document.docx" \
  "/full/path/to/data.xlsx" \
  "/full/path/to/slides.pptx" \
  "/full/path/to/reference.pdf"
```

The first run should open Google sign-in and consent in your browser. After approval:

- `token.json` is stored in the project folder.
- The files are uploaded to My Drive root.
- Compatible files open as native Google Workspace files.
- Other files open in Google Drive.

To switch the authorised Google account later:

```bash
cd ~/open-in-google-drive
rm token.json
```

Run the action again and choose the new account during sign-in.

---

## 7. Create the Finder Quick Action in Automator

1. Open **Automator**.
2. Choose **New Document**.
3. Select **Quick Action**.
4. At the top, configure:
   - **Workflow receives current:** `files or folders`
   - **in:** `Finder`
   - **Image:** optional - choose a Drive-like or upload icon
   - **Color:** optional
5. Search for **Run Shell Script** and drag it into the workflow.
6. Set:
   - **Shell:** `/bin/zsh`
   - **Pass input:** `as arguments`
7. Paste this, changing the folder path if you placed it elsewhere:

```zsh
"$HOME/open-in-google-drive/open_in_google_drive_wrapper.sh" "$@"
```

8. Save the Quick Action as:

```text
Open in Google Drive
```

The action should now appear when you right-click files in Finder under **Quick Actions**. Depending on Finder settings, it may also appear directly in the contextual menu.

Although Automator says `files or folders`, this MVP deliberately rejects folders. Selecting a folder produces a failure notification rather than recursively uploading it.

---

## 8. Use it

1. Select one or more files in Finder.
2. Right-click.
3. Choose **Quick Actions > Open in Google Drive**.
4. Wait for the browser tabs and completion notification.

For multiple files, each successful upload opens in a separate browser tab. The script inserts a short delay between tabs so browsers are less likely to suppress them.

---

## Behaviour and limitations

### My Drive root

The upload metadata does not specify a parent folder, so newly created files are placed in the root of My Drive.

### Duplicate names

Google Drive permits duplicate filenames. Running the action twice creates another file with the same name. This MVP never searches for, replaces, or deletes an existing file.

### Converted filenames

Converted files lose the local extension:

```text
Lesson Plan.docx -> Lesson Plan
Class Data.csv -> Class Data
Unit Slides.pptx -> Unit Slides
```

Unchanged uploads retain their full filenames:

```text
Reference.pdf -> Reference.pdf
Video.mp4 -> Video.mp4
```

### Office compatibility

Conversion quality is controlled by Google. Complex Word layouts, Excel macros, Power Query, unsupported formulas, embedded fonts, advanced animations, and some media may not survive conversion exactly.

`.xlsm` files can be converted to Sheets, but VBA macros are not converted to Google Apps Script.

### Password-protected or encrypted files

Google generally cannot convert password-protected Office files. The fallback upload may still store the original file unchanged.

### Apple iWork

Native `.pages`, `.numbers`, and `.key` files are uploaded unchanged. Export them from the Apple app to DOCX, XLSX, or PPTX first if you want native Google conversion.

### Permissions

The `drive.file` OAuth scope is intentionally narrower than full Drive access. It is sufficient for this create-and-open workflow.

---

## Logs and troubleshooting

Logs are written to:

```text
~/Library/Logs/OpenInGoogleDrive/open_in_google_drive.log
~/Library/Logs/OpenInGoogleDrive/automator.log
```

View the recent Automator log:

```bash
tail -n 100 ~/Library/Logs/OpenInGoogleDrive/automator.log
```

### Quick Action does not appear

- Confirm the workflow receives `files or folders` in `Finder`.
- Open **System Settings > General > Login Items & Extensions > Finder** or the relevant Extensions settings and ensure the Quick Action is enabled.
- In Finder, check **Quick Actions > Customise**.
- Restart Finder if needed:

```bash
killall Finder
```

### `client_secret.json` missing

Download a Desktop app OAuth client JSON and put it beside the Python script with the exact filename `client_secret.json`.

### `redirect_uri_mismatch`

Delete the incorrect OAuth client and create a new OAuth client with application type **Desktop app**. Do not use Web application credentials.

### Access blocked or app not verified

For a private MVP in testing mode, add the Google account you are using as a test user. If this is an organisational account, an administrator may restrict third-party or unverified OAuth applications.

### Wrong Google account

Delete `token.json`, then use the Finder action again and sign in with the intended account.

### Browser does not open

The upload may still have succeeded. Check My Drive and the logs. You can also test without browser opening:

```bash
./.venv/bin/python3 open_in_google_drive.py --no-open "/path/to/file.pdf"
```

### Conversion fails

The script automatically retries as a normal unchanged upload. The log records that fallback. This is intentional and prevents a single conversion incompatibility from blocking the file entirely.

---

## Files in this bundle

- `open_in_google_drive.py` - authentication, routing, upload, conversion, browser opening, notifications, and logging
- `open_in_google_drive_wrapper.sh` - Finder/Automator wrapper
- `install.command` - creates the virtual environment and installs dependencies
- `requirements.txt` - Python dependencies
- `README.md` - installation and operating instructions

## Security note

`token.json` contains a reusable OAuth token for the chosen Google account. The script attempts to restrict it to the current macOS user. Keep the project folder private, do not commit credentials to GitHub, and revoke the app through your Google Account security settings if the Mac is lost or the token may have been exposed.
