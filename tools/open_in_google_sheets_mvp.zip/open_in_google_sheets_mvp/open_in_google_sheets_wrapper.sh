#!/bin/zsh
# Wrapper intended for use inside an Automator Quick Action.
# Pass input as arguments, and Automator will hand us one or more selected files.

set -euo pipefail

SCRIPT_DIR="$HOME/open-in-google-sheets"
PYTHON_BIN="$SCRIPT_DIR/.venv/bin/python3"
PYTHON_SCRIPT="$SCRIPT_DIR/open_in_google_sheets.py"

if [[ $# -lt 1 ]]; then
  osascript -e 'display alert "Open in Google Sheets" message "No file was provided to the Quick Action." as critical'
  exit 1
fi

if [[ ! -x "$PYTHON_BIN" ]]; then
  osascript -e 'display alert "Open in Google Sheets" message "Python environment not found at ~/open-in-google-sheets/.venv. Finish the setup steps first." as critical'
  exit 1
fi

if [[ ! -f "$PYTHON_SCRIPT" ]]; then
  osascript -e 'display alert "Open in Google Sheets" message "Python script not found at ~/open-in-google-sheets/open_in_google_sheets.py." as critical'
  exit 1
fi

# For now, handle only the first selected file.
"$PYTHON_BIN" "$PYTHON_SCRIPT" "$1"
