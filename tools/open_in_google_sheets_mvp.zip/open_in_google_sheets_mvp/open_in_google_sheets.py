#!/usr/bin/env python3
"""
Open a local CSV file in Google Sheets by:
1. Authenticating the user with Google OAuth (desktop flow)
2. Uploading + converting the CSV into a native Google Sheets file in My Drive root
3. Opening the resulting Google Sheets URL in the default browser

Setup expectations:
- A Google Cloud OAuth Desktop App client credentials JSON file is stored next to this script as client_secret.json
- Required pip packages are installed
- Drive API is enabled in the Google Cloud project
"""

from __future__ import annotations

import json
import mimetypes
import os
import sys
import webbrowser
from pathlib import Path
from typing import Any

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload

# Use the narrowest scope that still supports creating files in Drive.
SCOPES = ["https://www.googleapis.com/auth/drive.file"]
GOOGLE_SHEETS_MIME = "application/vnd.google-apps.spreadsheet"
CSV_MIME = "text/csv"

APP_DIR = Path(__file__).resolve().parent
CLIENT_SECRET_FILE = APP_DIR / "client_secret.json"
TOKEN_FILE = APP_DIR / "token.json"


def eprint(*args: Any) -> None:
    print(*args, file=sys.stderr)


def validate_csv_path(path_str: str) -> Path:
    path = Path(path_str).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if not path.is_file():
        raise ValueError(f"Not a file: {path}")
    if path.suffix.lower() != ".csv":
        raise ValueError(f"File is not a CSV: {path}")
    return path


def load_credentials() -> Credentials:
    creds: Credentials | None = None

    if TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

    if creds and creds.valid:
        return creds

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
        TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
        return creds

    if not CLIENT_SECRET_FILE.exists():
        raise FileNotFoundError(
            f"Missing OAuth client credentials file: {CLIENT_SECRET_FILE}\n"
            "Download your Desktop app OAuth JSON from Google Cloud and save it as client_secret.json next to this script."
        )

    flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRET_FILE), SCOPES)
    # Opens the browser for consent/login if needed.
    creds = flow.run_local_server(host="127.0.0.1", port=0, open_browser=True)
    TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
    return creds


def upload_and_convert_csv(csv_path: Path) -> dict[str, Any]:
    creds = load_credentials()
    service = build("drive", "v3", credentials=creds)

    metadata = {
        "name": csv_path.stem,
        "mimeType": GOOGLE_SHEETS_MIME,
        "parents": ["root"],
    }

    media = MediaFileUpload(str(csv_path), mimetype=CSV_MIME, resumable=True)

    created = (
        service.files()
        .create(
            body=metadata,
            media_body=media,
            fields="id,name,webViewLink,mimeType,parents",
            supportsAllDrives=False,
        )
        .execute()
    )

    return created


def open_sheet_url(file_info: dict[str, Any]) -> str:
    sheet_id = file_info["id"]
    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/edit"
    webbrowser.open(url)
    return url


def main() -> int:
    if len(sys.argv) != 2:
        eprint("Usage: open_in_google_sheets.py /full/path/to/file.csv")
        return 2

    try:
        csv_path = validate_csv_path(sys.argv[1])
        file_info = upload_and_convert_csv(csv_path)
        url = open_sheet_url(file_info)
        print(json.dumps({
            "status": "ok",
            "name": file_info.get("name"),
            "id": file_info.get("id"),
            "url": url,
        }, ensure_ascii=False))
        return 0
    except (FileNotFoundError, ValueError) as exc:
        eprint(f"Error: {exc}")
        return 1
    except HttpError as exc:
        eprint("Google API error:")
        eprint(str(exc))
        return 1
    except Exception as exc:
        eprint(f"Unexpected error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
