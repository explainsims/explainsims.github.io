# Open in Google Sheets - macOS Quick Action MVP

This MVP lets you right-click a `.csv` file in Finder, choose **Open in Google Sheets**, and have it:

1. authenticate with Google if needed,
2. upload the CSV to **My Drive root**,
3. convert it into a native Google Sheets file, and
4. open the sheet in the default browser.

## What you are building

- **Finder Quick Action** for `.csv` files
- **Python script** to handle Google OAuth + Drive upload/conversion
- **Google Cloud OAuth Desktop App** credentials

## What this uses

- Google OAuth desktop flow
- Google Drive API file create/upload with conversion to Google Sheets
- macOS Automator Quick Action

## 1. Install Python if needed

Check whether Python 3 is already available:

```bash
python3 --version
```

If not, install it with Homebrew:

```bash
brew install python
```

## 2. Create the local app folder

```bash
mkdir -p ~/open-in-google-sheets
```

Copy these files into that folder:

- `open_in_google_sheets.py`
- `requirements.txt`
- later: `client_secret.json`

## 3. Create a virtual environment and install dependencies

```bash
cd ~/open-in-google-sheets
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

## 4. Create the Google Cloud project pieces

In Google Cloud:

1. Create or choose a project.
2. Enable the **Google Drive API**.
3. Configure the OAuth consent screen.
4. Create an OAuth client of type **Desktop app**.
5. Download the OAuth JSON credentials file.

Save that downloaded file as:

```text
~/open-in-google-sheets/client_secret.json
```

## 5. First manual test

Run this once from Terminal before wiring up Finder:

```bash
cd ~/open-in-google-sheets
./.venv/bin/python3 open_in_google_sheets.py "/full/path/to/your/file.csv"
```

What should happen:

- your browser opens for Google login/consent if needed,
- the CSV is uploaded and converted,
- the new Google Sheet opens in the browser,
- `token.json` is created locally for future runs.

## 6. Create the Finder right-click action

Open **Automator** and create a new **Quick Action**.

Set it like this:

- **Workflow receives current:** `files or folders`
- **in:** `Finder`
- optionally check image input is ignored if shown

Then add **Run Shell Script**.

Set:

- **Shell:** `/bin/zsh`
- **Pass input:** `as arguments`

Paste this wrapper content:

```zsh
#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$HOME/open-in-google-sheets"
PYTHON_BIN="$SCRIPT_DIR/.venv/bin/python3"
PYTHON_SCRIPT="$SCRIPT_DIR/open_in_google_sheets.py"

if [[ $# -lt 1 ]]; then
  osascript -e 'display alert "Open in Google Sheets" message "No file was provided to the Quick Action." as critical'
  exit 1
fi

if [[ ! -x "$PYTHON_BIN" ]]; then
  osascript -e 'display alert "Open in Google Sheets" message "Python environment not found at ~/open-in-google-sheets/.venv. Finish the setup steps first." as critical'
  exit 1
fi

if [[ ! -f "$PYTHON_SCRIPT" ]]; then
  osascript -e 'display alert "Open in Google Sheets" message "Python script not found at ~/open-in-google-sheets/open_in_google_sheets.py." as critical'
  exit 1
fi

"$PYTHON_BIN" "$PYTHON_SCRIPT" "$1"
```

Save the Quick Action as:

```text
Open in Google Sheets
```

Now right-click a CSV in Finder and you should see that action.

## 7. Notes and limitations

- This version handles the **first selected file only**.
- It creates a **new Google Sheet** each time. It does not update an existing sheet.
- It uploads to **My Drive root** by explicitly setting the parent to `root`.
- It authenticates the app itself through Google OAuth. It does **not** officially piggyback on whatever browser tab/profile happens to be logged in already.
- If you use multiple Google accounts, the one that authorizes the app is the one that receives the uploaded file.

## 8. Scope choice

The script uses the narrow `drive.file` scope, which is the right starting point for an app that only needs to create and access files it created.

## 9. Next upgrades worth doing

- Restrict the Quick Action to CSV files only
- Support multiple selected CSV files
- Add better duplicate-name handling
- Add logging
- Save into a specific Drive folder instead of root
- Package as a signed macOS app
- Store token more cleanly in Keychain-backed storage

## Troubleshooting

### `redirect_uri_mismatch`
Your OAuth client setup is wrong or the credentials file is not the correct Desktop App client.

### Browser login succeeds but upload fails
Usually one of:
- Drive API not enabled
- wrong credentials JSON
- bad scope/token from a previous setup

In that case, delete `token.json` and authenticate again.

### Nothing appears in Finder context menu
Make sure the Quick Action is saved and enabled, then relaunch Finder if needed.
